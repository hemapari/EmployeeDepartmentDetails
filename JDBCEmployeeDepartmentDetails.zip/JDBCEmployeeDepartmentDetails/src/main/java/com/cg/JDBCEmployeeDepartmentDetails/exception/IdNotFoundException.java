package com.cg.JDBCEmployeeDepartmentDetails.exception;

public class IdNotFoundException extends Exception{
	public IdNotFoundException() {}
	public IdNotFoundException(String s) {
		super(s);
	}
}
