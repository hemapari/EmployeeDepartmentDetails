package com.cg.JDBCEmployeeDepartmentDetails.department.service;
import java.util.List;



import com.cg.JDBCEmployeeDepartmentDetails.department.dao.DepartmentRepository;
import com.cg.JDBCEmployeeDepartmentDetails.department.dao.DepartmentRepositoryImp;
import com.cg.JDBCEmployeeDepartmentDetails.dto.Department;
import com.cg.JDBCEmployeeDepartmentDetails.dto.Employee;
import com.cg.JDBCEmployeeDepartmentDetails.exception.DepartmentNameNotFoundException;
import com.cg.JDBCEmployeeDepartmentDetails.exception.EmployeeNameNotFoundException;
import com.cg.JDBCEmployeeDepartmentDetails.exception.IdNotFoundException;

public class DepartmentServiceImp implements DepartmentService{

	DepartmentRepository dao;
	
	public DepartmentServiceImp() {
		dao=new DepartmentRepositoryImp();

	}

	public Department addDepartment(Department department) throws DepartmentNameNotFoundException
	{
		return dao.save(department);
	}

	public List<Employee> searchByDepartmentName(String name) throws DepartmentNameNotFoundException{
		List<Employee> empp=dao.findByDepartmentName(name);
		if(empp.isEmpty())
		throw new DepartmentNameNotFoundException("Department name not found (or) Employee not yet assigned to the particular department");
		return empp;
		
	}
}



