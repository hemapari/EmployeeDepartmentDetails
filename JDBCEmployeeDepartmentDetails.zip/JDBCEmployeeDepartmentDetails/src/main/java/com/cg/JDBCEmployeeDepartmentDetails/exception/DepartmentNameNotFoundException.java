package com.cg.JDBCEmployeeDepartmentDetails.exception;

public class DepartmentNameNotFoundException extends Exception {
	public DepartmentNameNotFoundException() {}
	public DepartmentNameNotFoundException(String str) {
		super(str);
	}
	
}
