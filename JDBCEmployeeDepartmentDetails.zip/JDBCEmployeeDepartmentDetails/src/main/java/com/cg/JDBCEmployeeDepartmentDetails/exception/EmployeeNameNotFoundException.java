package com.cg.JDBCEmployeeDepartmentDetails.exception;

public class EmployeeNameNotFoundException extends Exception{
	public EmployeeNameNotFoundException() {}
	public EmployeeNameNotFoundException(String msg) {
		super(msg);
	}
}
