package com.cg.JDBCEmployeeDepartmentDetails.department.dao;
import java.util.List;

import com.cg.JDBCEmployeeDepartmentDetails.dto.Department;
import com.cg.JDBCEmployeeDepartmentDetails.dto.Employee;
import com.cg.JDBCEmployeeDepartmentDetails.exception.DepartmentNameNotFoundException;
import com.cg.JDBCEmployeeDepartmentDetails.exception.IdNotFoundException;

public interface DepartmentRepository {
	public Department save(Department department)throws DepartmentNameNotFoundException;
	public List<Employee> findByDepartmentName(String name)throws DepartmentNameNotFoundException;
}
