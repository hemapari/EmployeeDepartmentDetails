
package com.cg.JDBCEmployeeDepartmentDetails.employee.service;
import java.util.ArrayList;
import java.util.List;

import com.cg.JDBCEmployeeDepartmentDetails.department.dao.DepartmentRepository;
import com.cg.JDBCEmployeeDepartmentDetails.department.dao.DepartmentRepositoryImp;
import com.cg.JDBCEmployeeDepartmentDetails.dto.Department;
import com.cg.JDBCEmployeeDepartmentDetails.dto.Employee;
import com.cg.JDBCEmployeeDepartmentDetails.employee.dao.EmployeeRepository;
import com.cg.JDBCEmployeeDepartmentDetails.employee.dao.EmployeeRepositoryImp;
import com.cg.JDBCEmployeeDepartmentDetails.exception.DepartmentNameNotFoundException;
import com.cg.JDBCEmployeeDepartmentDetails.exception.EmployeeNameNotFoundException;
import com.cg.JDBCEmployeeDepartmentDetails.exception.IdNotFoundException;

public class EmployeeServiceImp implements EmployeeService {
    EmployeeRepository dao;
	
	public EmployeeServiceImp() {
		dao=new EmployeeRepositoryImp();}
	
	public Employee addEmployee(Employee employee) throws IdNotFoundException
	{Employee emp=dao.save(employee);
	if(emp==null)
		throw new IdNotFoundException("Employee id is already found");
	return emp;
		
	}

	public Employee updateEmployeeDetails(Employee employee) throws IdNotFoundException
	{
		return dao.save(employee);
		
	}

	public Employee searchByEmployeeId(int id) throws IdNotFoundException
	{
		Employee emp=dao.findByEmployeeId(id);
		if(emp==null)
			throw new IdNotFoundException("Employee id not found");
		return emp;
	}

	public List<Employee> searchByEmployeeName(String name)throws EmployeeNameNotFoundException{ 
		List<Employee> emps=dao.findByEmployeeName(name);
		if(emps.isEmpty())
			throw new EmployeeNameNotFoundException("Employee name not found");
		return emps;
	}

}
