package com.cg.JDBCEmployeeDepartmentDetails.department.dao;
import java.sql.Array;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.JDBCEmployeeDepartmentDetails.dto.Department;
import com.cg.JDBCEmployeeDepartmentDetails.dto.Employee;
import com.cg.JDBCEmployeeDepartmentDetails.exception.DepartmentNameNotFoundException;
import com.cg.JDBCEmployeeDepartmentDetails.exception.IdNotFoundException;
import com.cg.JDBCEmployeeDepartmentDetails.util.DBUtil;

public class DepartmentRepositoryImp implements DepartmentRepository {
	PreparedStatement ps;
	ResultSet rs;

	Connection  con=null;

	public Department save(Department department) throws DepartmentNameNotFoundException{
		
		con = DBUtil.getConnection();
		String query_insert = "INSERT INTO department (dept_id,dept_name)  VALUES(?,?)";
		try {
			ps = con.prepareStatement(query_insert);
           
			ps.setInt(1, department.getId());
			ps.setString(2, department.getName());

			ps.executeUpdate();

		} catch (SQLException e) {
			throw new DepartmentNameNotFoundException("Department name already exist");

		}

		finally {
			try {
				ps.close();
				con.close();

			} catch (SQLException e) {
				throw new DepartmentNameNotFoundException(" Department name already exist");
			}
		}
		return department;
	}

	
	public List<Employee> findByDepartmentName(String name) throws DepartmentNameNotFoundException
	{
		con = DBUtil.getConnection();
		List<Employee> emp=new ArrayList<Employee>();
		
		try {
			ps=con.prepareStatement("select e.emp_name,e.emp_id from employee e join department d on e.emp_deptName=d.dept_name where d.dept_name=?"); 
			ps.setString(1, name);
			rs=ps.executeQuery();
			if(rs!=null) {
				while(rs.next()) {
					Employee e=new Employee();
					e.setName(rs.getString(1));
					e.setId(rs.getInt(2));
					emp.add(e);
				}	
			}
			
				
		}
		catch(SQLException e) {
			throw new DepartmentNameNotFoundException("Department name not found (or) Employee not yet assigned to the particular department");
		}
		finally {
			try {
				ps.close();
				con.close();

			} catch (SQLException e) {
				throw new DepartmentNameNotFoundException("Department name not found (or) Employee not yet assigned to the particular department");
			}
		}
		return emp;
	}

	
	}
