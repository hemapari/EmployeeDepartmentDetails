package com.cg.JDBCEmployeeDepartmentDetails.employee.dao;
import java.util.List;

import com.cg.JDBCEmployeeDepartmentDetails.dto.Employee;
import com.cg.JDBCEmployeeDepartmentDetails.exception.DepartmentNameNotFoundException;
import com.cg.JDBCEmployeeDepartmentDetails.exception.EmployeeNameNotFoundException;
import com.cg.JDBCEmployeeDepartmentDetails.exception.IdNotFoundException;

public interface EmployeeRepository {
	public Employee save(Employee employee) throws IdNotFoundException;
	public Employee findByEmployeeId(int id)throws IdNotFoundException;
	public List<Employee> findByEmployeeName(String name)throws EmployeeNameNotFoundException;
}
