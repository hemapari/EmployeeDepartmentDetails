package com.cg.JDBCEmployeeDepartmentDetails.dto;
import java.util.List;

public class Department {
	
private String name;
private int id;
private List<Employee> employees;

public  Department() {}

public Department(String name, int id, List<Employee> employees) {
	super();
	this.name = name;
	this.id = id;
	this.employees = employees;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public List<Employee> getEmployees() {
	return employees;
}

public void setEmployees(List<Employee> employees) {
	this.employees = employees;
}

@Override
public String toString() {
	return "Department [name=" + name + ", id=" + id + ", employees=" + employees + "]";
}



}
