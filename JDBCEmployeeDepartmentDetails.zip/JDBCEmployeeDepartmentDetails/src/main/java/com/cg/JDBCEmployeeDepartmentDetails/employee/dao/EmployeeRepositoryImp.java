package com.cg.JDBCEmployeeDepartmentDetails.employee.dao;
import java.math.BigInteger;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


import java.util.List;

import com.cg.JDBCEmployeeDepartmentDetails.dto.Address;
import com.cg.JDBCEmployeeDepartmentDetails.dto.Department;
import com.cg.JDBCEmployeeDepartmentDetails.dto.Employee;
import com.cg.JDBCEmployeeDepartmentDetails.exception.DepartmentNameNotFoundException;
import com.cg.JDBCEmployeeDepartmentDetails.exception.EmployeeNameNotFoundException;
import com.cg.JDBCEmployeeDepartmentDetails.exception.IdNotFoundException;
import com.cg.JDBCEmployeeDepartmentDetails.util.DBUtil;

public class EmployeeRepositoryImp implements EmployeeRepository {
	Connection con = null;

	PreparedStatement pstm;
	ResultSet rs;
	List<Employee> emp=new ArrayList<Employee>();
	Address add=new Address();
	public Employee save(Employee employee) throws IdNotFoundException
	{
		con=DBUtil.getConnection();
		try {
			
			pstm=con.prepareStatement("select emp_id from employee where emp_id=?");
			pstm.setInt(1, employee.getId());
			
			if(rs==null)
			{
				
					pstm = con.prepareStatement("INSERT INTO employee(emp_id,emp_name,emp_deptName,emp_salary,emp_mobile) VALUES(?,?,?,?,?)");

					pstm.setInt(1, employee.getId());
					pstm.setString(2, employee.getName());
					pstm.setString(3,employee.getDepartmentName() );
					pstm.setDouble(4, employee.getSalary());
					pstm.setString(5, employee.getMobile().toString());
					
					pstm.executeUpdate();
					
					
					
					pstm=con.prepareStatement("INSERT INTO address(add_city,add_state,add_pincode,FKemp_id) VALUES(?,?,?,?) ");
					
					pstm.setString(1, employee.getAddress().getCity());
					pstm.setString(2, employee.getAddress().getState());
					pstm.setInt(3, employee.getAddress().getPincode());
					pstm.setInt(4, employee.getId());

					pstm.executeUpdate();
			}
			
			if(rs!=null)
			{
				pstm=con.prepareStatement("update employee set emp_salary=? where emp_id=?");
				pstm.setDouble(1, employee.getSalary());
				pstm.setInt(2, employee.getId());
				pstm.executeUpdate();
			
				pstm=con.prepareStatement("select e.emp_id,e.emp_name,e.emp_deptName,e.emp_salary,e.emp_mobile,a.add_city,a.add_state,a.add_pincode from employee e join address a on a.FKemp_id=e.emp_id  where e.emp_id=?"); 
				pstm.setInt(1, employee.getId());
				rs=pstm.executeQuery();
				
				if(rs!=null)
				{
					while(rs.next()) {
					employee.setId(rs.getInt(1));
					employee.setName(rs.getString(2));
					employee.setDepartmentName(rs.getString(3));
					employee.setSalary(rs.getDouble(4));
					employee.setMobile(new BigInteger(rs.getString(5).toString()));
					add.setCity(rs.getString(6));
					add.setState(rs.getString(7));
					add.setPincode(rs.getInt(8));
					employee.setAddress(add);
				
				
			}}}
			
			
			
			
		} catch (SQLException e) {
			throw new IdNotFoundException("Employee id is already found/Assign department name correctly");
		}

		finally {
			try {
				pstm.close();
				con.close();

			} catch (SQLException e) {
				throw new IdNotFoundException("Employee id is already found/Assign department name correctly");

			}
		}
		return employee;
	}

	public Employee findByEmployeeId(int id) throws IdNotFoundException 
	{
		con=DBUtil.getConnection();
		Employee employee=null;
		Address add=new Address();
		try {
			pstm=con.prepareStatement("select e.emp_id,e.emp_name,e.emp_deptName,e.emp_salary,e.emp_mobile,a.add_city,a.add_state,a.add_pincode from employee e join address a on a.FKemp_id=e.emp_id  where e.emp_id=?"); 
			pstm.setInt(1, id);
			rs=pstm.executeQuery();
			if(rs!=null) {
				while(rs.next()) {
					employee=new Employee();
					employee.setId(rs.getInt(1));
					employee.setName(rs.getString(2));
					employee.setDepartmentName(rs.getString(3));
					employee.setSalary(rs.getDouble(4));
					employee.setMobile(new BigInteger(rs.getString(5).toString()));
					add.setCity(rs.getString(6));
					add.setState(rs.getString(7));
					add.setPincode(rs.getInt(8));
					employee.setAddress(add);
				}	
			}
			
			 
				
	}
		catch(SQLException e) {
			throw new IdNotFoundException("Employee id not found");
		}
		finally {
			try {
				pstm.close();
				con.close();

			} catch (SQLException e) {
				throw new IdNotFoundException("Employee id not found");
			}
		}
		return employee;
	}

	public List<Employee> findByEmployeeName(String name) throws EmployeeNameNotFoundException 
	{
		con=DBUtil.getConnection();
		List<Employee> employee=new ArrayList<Employee>();
		try {
			pstm=con.prepareStatement("select emp_name,emp_id from employee where emp_name=?"); 
			pstm.setString(1, name);
			rs=pstm.executeQuery();
			if(rs!=null) {
				while(rs.next()) {
					Employee e=new Employee();
					e.setName(rs.getString(1));
					e.setId(rs.getInt(2));
					employee.add(e);
				}	
			}
		 
			
		}
		catch(SQLException ex) {
			throw new EmployeeNameNotFoundException("Employee name not found");
		}
		finally {
			try {
				pstm.close();
				con.close();

			} catch (SQLException e) {
				throw new EmployeeNameNotFoundException("Employee name not found");
			}
		}
		
		return employee;
	}
	
	
	}
		




