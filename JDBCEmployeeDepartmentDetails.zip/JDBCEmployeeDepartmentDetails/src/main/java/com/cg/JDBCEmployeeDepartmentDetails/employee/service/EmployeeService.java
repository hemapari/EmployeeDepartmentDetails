package com.cg.JDBCEmployeeDepartmentDetails.employee.service;
import java.util.List;


import com.cg.JDBCEmployeeDepartmentDetails.dto.Employee;
import com.cg.JDBCEmployeeDepartmentDetails.exception.DepartmentNameNotFoundException;
import com.cg.JDBCEmployeeDepartmentDetails.exception.EmployeeNameNotFoundException;
import com.cg.JDBCEmployeeDepartmentDetails.exception.IdNotFoundException;

public interface EmployeeService {
	public Employee addEmployee(Employee employee)throws IdNotFoundException;
	public Employee updateEmployeeDetails(Employee employee)throws IdNotFoundException;
	public Employee searchByEmployeeId(int id)throws IdNotFoundException;
	public List<Employee> searchByEmployeeName(String name)throws EmployeeNameNotFoundException;
}
