package com.cg.JDBCEmployeeDepartmentDetails.department.service;
import java.util.List;

import java.util.Map;
import com.cg.JDBCEmployeeDepartmentDetails.dto.Department;
import com.cg.JDBCEmployeeDepartmentDetails.dto.Employee;
import com.cg.JDBCEmployeeDepartmentDetails.exception.DepartmentNameNotFoundException;


public interface DepartmentService {
	public Department addDepartment(Department department)throws DepartmentNameNotFoundException;
	public List<Employee> searchByDepartmentName(String name)throws DepartmentNameNotFoundException;
}
