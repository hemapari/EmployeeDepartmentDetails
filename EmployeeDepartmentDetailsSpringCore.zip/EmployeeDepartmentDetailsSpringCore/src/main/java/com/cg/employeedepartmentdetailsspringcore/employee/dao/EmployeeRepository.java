package com.cg.employeedepartmentdetailsspringcore.employee.dao;
import java.util.List;

import com.cg.employeedepartmentdetailsspringcore.dto.Employee;
import com.cg.employeedepartmentdetailsspringcore.exception.EmployeeNameNotFoundException;
import com.cg.employeedepartmentdetailsspringcore.exception.IdNotFoundException;
/**Written by Hemavathi Ramalingam on 04-05-2019
 * last modified on 05-05-2019
 * The interface EmployeeRepository declares the methods
 */

public interface EmployeeRepository {
	public Employee save(Employee employee);
	public Employee findByEmployeeId(int id)throws IdNotFoundException;
	public List<Employee> findByEmployeeName(String name)throws EmployeeNameNotFoundException;
}
