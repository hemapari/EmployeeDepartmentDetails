package com.cg.employeedepartmentdetailsspringcore.department.dao;
import java.util.ArrayList;


import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.employeedepartmentdetailsspringcore.dto.Department;
import com.cg.employeedepartmentdetailsspringcore.dto.Employee;
import com.cg.employeedepartmentdetailsspringcore.exception.DepartmentNameNotFoundException;
import com.cg.employeedepartmentdetailsspringcore.util.DBUtil;
/**Written by Hemavathi Ramalingam on 14-05-2019
 * last modified on 14-05-2019
 * This class DepartmentRepositoryImp implements the methods of DepartmentRepository
 */
@Repository("deptDao")
public class DepartmentRepositoryImp implements DepartmentRepository {
	
	
	/**Written by Hemavathi Ramalingam on 14-05-2019
	 * last modified on 14-05-2019
	 * This save method is used to save the department 
	 */
	public Department save(Department department) {
		DBUtil.deptEmployees.add(department);
		return department;}
	
	
	/**Written by Hemavathi Ramlaingam on 04-05-2019
	 * last modified on 05-05-2019
	 * This findByDepartmentName method is used to list the id and name of the employees under the department if the particular department name is found
	 * otherwise it will throw DepartmentNameNotFoundException
	 */
	
	public List<Employee> findByDepartmentName(String name) throws DepartmentNameNotFoundException
	{
		List<Employee> empSearch = new ArrayList();
		for (Department deptEmployee : DBUtil.deptEmployees)
			for (Employee employee : DBUtil.employeeList) {
				if (deptEmployee.getName().equals(name)) {
					if (employee.getDepartmentName().equals(name))
						empSearch.add(employee);
				}
			}
		if (empSearch.isEmpty())
			throw new DepartmentNameNotFoundException("Department Name not found!");
		return empSearch;
	}
}
