package com.cg.employeedepartmentdetailsspringcore.employee.service;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.employeedepartmentdetailsspringcore.dto.Employee;
import com.cg.employeedepartmentdetailsspringcore.employee.dao.EmployeeRepository;
import com.cg.employeedepartmentdetailsspringcore.employee.dao.EmployeeRepositoryImp;
import com.cg.employeedepartmentdetailsspringcore.exception.EmployeeNameNotFoundException;
import com.cg.employeedepartmentdetailsspringcore.exception.IdNotFoundException;
/**Written by Hemavathi Ramalingam on 04-05-2019
 * last modified on 05-05-2019
 * The interface EmployeeServiceImp implements the methods of EmployeeService
 */
@Service("empService")
public class EmployeeServiceImp implements EmployeeService {
	@Autowired
    EmployeeRepository dao;
	
	/**Written by Hemavathi Ramalingam on 04-05-2019
	 * last modified on 05-05-2019
	 * This method addEmployee links to the dao layer save method
	 */
	public Employee addEmployee(Employee employee)
		{return dao.save(employee);}

	/**Written by Hemavathi Ramalingam on 04-05-2019
	 * last modified on 05-05-2019
	 * This method updateEmployeeDetails links to the dao layer save method
	 */
	public Employee updateEmployeeDetails(Employee employee) {
		return dao.save(employee);
	}

	/**Written by Hemavathi Ramalingam on 04-05-2019
	 * last modified on 05-05-2019
	 * This method searchByEmployeeId links to the dao layer findByEmployeeId method
	 */
	public Employee searchByEmployeeId(int id) throws IdNotFoundException {
		//return dao.findByEmployeeId(id);
		Employee emp=dao.findByEmployeeId(id);
		if(emp==null)
			throw new IdNotFoundException("Employee id not found");
		return emp;
	}

	/**Written by Hemavathi Ramalingam on 04-05-2019
	 * last modified on 05-05-2019
	 *  This method searchByEmployeeName links to the dao layer findByEmployeeName method
	 */
	public List<Employee> searchByEmployeeName(String name)throws EmployeeNameNotFoundException{ 
		//return dao.findByEmployeeName(name);
		List<Employee> emps=dao.findByEmployeeName(name);
		if(emps.isEmpty())
			throw new EmployeeNameNotFoundException("Employee name not found");
		return emps;
	}

}
