package com.cg.employeedepartmentdetailsspringcore.dto;



import java.math.BigInteger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
/**Written by Hemavathi Ramalingam on 04-05-2019
 * last modified on 05-05-2019
 * The class Employee is the bean which contains description about Employee
 */
@Component("employee")
@Scope("prototype")
public class Employee {

private int id;
private String name;
private String departmentName;
private double salary;
private BigInteger mobile;
private Address address;


public Employee() {}


public Employee(int id, String name, String departmentName, double salary, BigInteger mobile, Address address) {
	super();
	this.id = id;
	this.name = name;
	this.departmentName = departmentName;
	this.salary = salary;
	this.mobile = mobile;
	this.address = address;
}


public int getId() {
	return id;
}


public void setId(int id) {
	this.id = id;
}


public String getName() {
	return name;
}


public void setName(String name) {
	this.name = name;
}


public String getDepartmentName() {
	return departmentName;
}


public void setDepartmentName(String departmentName) {
	this.departmentName = departmentName;
}


public double getSalary() {
	return salary;
}


public void setSalary(double salary) {
	this.salary = salary;
}


public BigInteger getMobile() {
	return mobile;
}


public void setMobile(BigInteger mobile) {
	this.mobile = mobile;
}


public Address getAddress() {
	return address;
}


public void setAddress(Address address) {
	this.address = address;
}


@Override
public String toString() {
	return "Employee [id=" + id + ", name=" + name + ", DepartmentName=" + departmentName + ", salary=" + salary
			+ ", mobile=" + mobile + ", address=" + address + "]";
}




}
