package com.cg.employeedepartmentdetailsspringcore.department.service;
import java.util.List;

import java.util.Map;

import com.cg.employeedepartmentdetailsspringcore.dto.Department;
import com.cg.employeedepartmentdetailsspringcore.dto.Employee;
import com.cg.employeedepartmentdetailsspringcore.exception.DepartmentNameNotFoundException;
/**Written by Hemavathi Ramalingam on 04-05-2019
 * last modified on 05-05-2019
 * The interface DepartmentService declares the methods
 */

public interface DepartmentService {
	public Department addDepartment(Department department);
	public List<Employee> searchByDepartmentName(String name)throws DepartmentNameNotFoundException;
}
