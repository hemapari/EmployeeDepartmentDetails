package com.cg.employeedepartmentdetailsspringcore.department.dao;
import java.util.List;

import com.cg.employeedepartmentdetailsspringcore.dto.Department;
import com.cg.employeedepartmentdetailsspringcore.dto.Employee;
import com.cg.employeedepartmentdetailsspringcore.exception.DepartmentNameNotFoundException;
/**Written by Hemavathi Ramalingam on 04-05-2019
 * last modified on 05-05-2019
 * The interface DepartmentRepository declares the methods
 */

public interface DepartmentRepository {
	public Department save(Department department);
	public List<Employee> findByDepartmentName(String name)throws DepartmentNameNotFoundException;
}
