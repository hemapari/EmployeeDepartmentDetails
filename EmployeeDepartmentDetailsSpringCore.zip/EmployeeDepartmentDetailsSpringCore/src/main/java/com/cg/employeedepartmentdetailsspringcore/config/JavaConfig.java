package com.cg.employeedepartmentdetailsspringcore.config;

import org.springframework.beans.factory.annotation.Autowire;



import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**Written by Hemavathi Ramalingam on 04-05-2019
 * last modified on 05-05-2019
 * The class JavaConfig is used to configure all the classes under the com.cg.employeedepartmentdetailsspringcore package
 */

@Configuration
@ComponentScan("com.cg.employeedepartmentdetailsspringcore")
public class JavaConfig {
	
}
    
