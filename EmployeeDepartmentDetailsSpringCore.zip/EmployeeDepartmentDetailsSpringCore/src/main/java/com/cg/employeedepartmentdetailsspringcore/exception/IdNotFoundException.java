package com.cg.employeedepartmentdetailsspringcore.exception;
/**Written by Hemavathi Ramalingam on 04-05-2019
 * last modified on 05-05-2019
 * The class IdNotFoundException is the exception class ,it is thrown when id of the employee is not found
 */

public class IdNotFoundException extends Exception{
	public IdNotFoundException() {}
	public IdNotFoundException(String s) {
		super(s);
	}
}
