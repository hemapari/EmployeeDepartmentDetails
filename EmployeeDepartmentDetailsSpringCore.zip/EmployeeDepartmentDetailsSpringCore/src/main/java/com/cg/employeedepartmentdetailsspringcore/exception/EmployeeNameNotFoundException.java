package com.cg.employeedepartmentdetailsspringcore.exception;
/**Written by Hemavathi Ramalingam on 04-05-2019
 * last modified on 05-05-2019
 * The class EmployeeNameNotFoundException is the exception class ,it is thrown when name of the employee is not found
 */
public class EmployeeNameNotFoundException extends Exception{
	public EmployeeNameNotFoundException() {}
	public EmployeeNameNotFoundException(String msg) {
		super(msg);
	}
}
