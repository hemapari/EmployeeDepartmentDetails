package com.cg.employeedepartmentdetailsspringcore.employee.dao;
import java.util.ArrayList;

import java.util.List;
import org.springframework.stereotype.Repository;

import com.cg.employeedepartmentdetailsspringcore.dto.Department;
import com.cg.employeedepartmentdetailsspringcore.dto.Employee;
import com.cg.employeedepartmentdetailsspringcore.exception.EmployeeNameNotFoundException;
import com.cg.employeedepartmentdetailsspringcore.exception.IdNotFoundException;
import com.cg.employeedepartmentdetailsspringcore.util.DBUtil;
/**Written by Hemavathi Ramalingam on 14-05-2019
 * last modified on 14-05-2019
 * This class EmployeeRepositoryImp implements the methods of EmployeeRepository
 */
@Repository("dao")
public class EmployeeRepositoryImp implements EmployeeRepository {
	
	/**Written by Hemavathi Ramalingam on 14-05-2019
	 * last modified on 14-05-2019
	 * This save method is used to save the employee details 
	 */
	public Employee save(Employee employee) {
		DBUtil.employeeList.add(employee);
		return employee;
	}
	
	
	/**Written by Hemavathi Ramalingam on 14-05-2019
	 * last modified on 14-05-2019
	 * This findByEmployeeId method is used to display the employee details if the particular employee id is found
	 * otherwise it will throw IdNotFoundException
	 */
	public Employee findByEmployeeId(int id) throws IdNotFoundException
	{
		for (Employee employee : DBUtil.employeeList) {
			if (employee.getId() == id)
				return employee;}
			//return null;
		
		throw new IdNotFoundException("Id not found!");
	}
	
	
	/**Written by Hemavathi Ramalingam on 04-05-2019
	 * last modified on 05-05-2019
	 * This findByEmployeeName method is used to display the employee id if the particular employee name is found
	 *  otherwise it will throw EmployeeNameNotFoundException
	 */
	public List<Employee> findByEmployeeName(String name) throws EmployeeNameNotFoundException
	{
		List<Employee> empSearch = new ArrayList<Employee>();
		for (Employee employee : DBUtil.employeeList) {
			if (employee.getName().equals(name))
				empSearch.add(employee);
		}
		if (empSearch.isEmpty())
			throw new EmployeeNameNotFoundException("Employee Name not found!");
		return empSearch;
	}
}
