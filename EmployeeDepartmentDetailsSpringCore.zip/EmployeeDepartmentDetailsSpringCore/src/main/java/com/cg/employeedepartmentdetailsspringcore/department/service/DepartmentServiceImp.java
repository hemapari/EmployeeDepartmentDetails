package com.cg.employeedepartmentdetailsspringcore.department.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.employeedepartmentdetailsspringcore.department.dao.DepartmentRepository;
import com.cg.employeedepartmentdetailsspringcore.department.dao.DepartmentRepositoryImp;
import com.cg.employeedepartmentdetailsspringcore.dto.Department;
import com.cg.employeedepartmentdetailsspringcore.dto.Employee;
import com.cg.employeedepartmentdetailsspringcore.exception.DepartmentNameNotFoundException;
/**Written by Hemavathi Ramalingam on 04-05-2019
 * last modified on 05-05-2019
 * The interface DepartmentServiceImp implements the methods of DepartmentService
 */
@Service("departmentService")
public class DepartmentServiceImp implements DepartmentService{
    @Autowired
	DepartmentRepository deptDao;
	
    /**Written by Hemavathi Ramalingam on 04-05-2019
	 * last modified on 05-05-2019
	 * This method addDepartment links to the dao layer save method
	 */
	public Department addDepartment(Department department) {
		return deptDao.save(department);
	}
	
	 /**Written by Hemavathi Ramalingam on 04-05-2019
		 * last modified on 05-05-2019
		 * This method searchByDepartmentName links to the dao layer findByDepartmentName method
		 */
	public List<Employee> searchByDepartmentName(String name) throws DepartmentNameNotFoundException{
		//return deptDao.findByDepartmentName(name);
		List<Employee> empp= deptDao.findByDepartmentName(name);
		if(empp.isEmpty())
			throw new DepartmentNameNotFoundException("Department name is not found");
			return empp;
	}
}
	



