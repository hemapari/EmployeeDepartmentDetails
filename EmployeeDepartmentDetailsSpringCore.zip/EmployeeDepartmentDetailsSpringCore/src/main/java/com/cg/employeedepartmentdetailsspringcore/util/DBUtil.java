package com.cg.employeedepartmentdetailsspringcore.util;
import java.util.ArrayList;

import java.util.List;

import com.cg.employeedepartmentdetailsspringcore.dto.Department;
import com.cg.employeedepartmentdetailsspringcore.dto.Employee;
/**Written by Hemavathi Ramalingam on 04-05-2019
 * last modified on 05-05-2019
 * The class DBUtil is used to store the List of Employees and Department
 */
public class DBUtil {
	public static List<Employee> employeeList=new ArrayList<Employee>();
	public static List<Department> deptEmployees=new ArrayList<Department>();
}
