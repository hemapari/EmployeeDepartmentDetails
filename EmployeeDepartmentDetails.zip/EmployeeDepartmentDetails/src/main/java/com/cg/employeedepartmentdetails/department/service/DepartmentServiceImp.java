package com.cg.employeedepartmentdetails.department.service;
import java.util.List;
import com.cg.employeedepartmentdetails.department.dao.DepartmentRepository;
import com.cg.employeedepartmentdetails.department.dao.DepartmentRepositoryImp;
import com.cg.employeedepartmentdetails.dto.Department;
import com.cg.employeedepartmentdetails.dto.Employee;
import com.cg.employeedepartmentdetails.exception.DepartmentNameNotFoundException;
import com.cg.employeedepartmentdetails.exception.IdNotFoundException;

public class DepartmentServiceImp implements DepartmentService{

	DepartmentRepository dao;
	
	public DepartmentServiceImp() {
		dao=new DepartmentRepositoryImp();

	}

	public Department addDepartment(Department department) {
		return dao.save(department);
	}

	public List<Employee> searchByDepartmentName(String name) throws DepartmentNameNotFoundException{
		return dao.findByDepartmentName(name);
	}
}
	



