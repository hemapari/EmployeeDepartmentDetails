package com.cg.employeedepartmentdetails.employee.service;
import java.util.List;
import com.cg.employeedepartmentdetails.department.dao.DepartmentRepository;
import com.cg.employeedepartmentdetails.department.dao.DepartmentRepositoryImp;
import com.cg.employeedepartmentdetails.dto.Employee;
import com.cg.employeedepartmentdetails.employee.dao.EmployeeRepository;
import com.cg.employeedepartmentdetails.employee.dao.EmployeeRepositoryImp;
import com.cg.employeedepartmentdetails.exception.EmployeeNameNotFoundException;
import com.cg.employeedepartmentdetails.exception.IdNotFoundException;

public class EmployeeServiceImp implements EmployeeService {
    EmployeeRepository dao;
	
	public EmployeeServiceImp() {
		dao=new EmployeeRepositoryImp();}
	
	public Employee addEmployee(Employee employee) {
		return dao.save(employee);
	}

	public Employee updateEmployeeDetails(Employee employee) {
		return dao.save(employee);
	}

	public Employee searchByEmployeeId(int id) throws IdNotFoundException {
		return dao.findByEmployeeId(id);
	}

	public List<Employee> searchByEmployeeName(String name)throws EmployeeNameNotFoundException{ 
		return dao.findByEmployeeName(name);
	}

}
