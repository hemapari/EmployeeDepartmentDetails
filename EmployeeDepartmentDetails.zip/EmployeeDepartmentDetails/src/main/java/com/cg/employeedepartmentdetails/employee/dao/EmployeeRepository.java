package com.cg.employeedepartmentdetails.employee.dao;
import java.util.List;
import com.cg.employeedepartmentdetails.dto.Employee;
import com.cg.employeedepartmentdetails.exception.EmployeeNameNotFoundException;
import com.cg.employeedepartmentdetails.exception.IdNotFoundException;

public interface EmployeeRepository {
	public Employee save(Employee employee);
	public Employee findByEmployeeId(int id)throws IdNotFoundException;
	public List<Employee> findByEmployeeName(String name)throws EmployeeNameNotFoundException;
}
