package com.cg.employeedepartmentdetails.department.service;
import java.util.List;
import java.util.Map;
import com.cg.employeedepartmentdetails.dto.Department;
import com.cg.employeedepartmentdetails.dto.Employee;
import com.cg.employeedepartmentdetails.exception.DepartmentNameNotFoundException;


public interface DepartmentService {
	public Department addDepartment(Department department);
	public List<Employee> searchByDepartmentName(String name)throws DepartmentNameNotFoundException;
}
