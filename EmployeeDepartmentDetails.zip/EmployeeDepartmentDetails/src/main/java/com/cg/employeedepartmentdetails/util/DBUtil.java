package com.cg.employeedepartmentdetails.util;
import java.util.ArrayList;
import java.util.List;
import com.cg.employeedepartmentdetails.dto.Department;
import com.cg.employeedepartmentdetails.dto.Employee;

public class DBUtil {
	public static List<Employee> employeeList=new ArrayList<Employee>();
	public static List<Department> deptEmployees=new ArrayList<Department>();
}
