package com.cg.employeedepartmentdetails.department.dao;
import java.util.ArrayList;
import java.util.List;
import com.cg.employeedepartmentdetails.dto.Department;
import com.cg.employeedepartmentdetails.dto.Employee;
import com.cg.employeedepartmentdetails.exception.DepartmentNameNotFoundException;
import com.cg.employeedepartmentdetails.exception.IdNotFoundException;
import com.cg.employeedepartmentdetails.util.DBUtil;

public class DepartmentRepositoryImp implements DepartmentRepository {

	public Department save(Department department) {
		DBUtil.deptEmployees.add(department);
		return department;}
	
	
public List<Employee> findByDepartmentName(String name)throws DepartmentNameNotFoundException 
{ List<Employee> empSearch=new ArrayList();
for(Department deptEmployee:DBUtil.deptEmployees)
	for(Employee employee:DBUtil.employeeList)
	{
	if(deptEmployee.getName().equals(name)) 
		{if(employee.getDepartmentName().equals(name)) 
		empSearch.add(employee);}}
if(empSearch.isEmpty())
	throw new DepartmentNameNotFoundException("Department Name not found!");
return empSearch;}}
