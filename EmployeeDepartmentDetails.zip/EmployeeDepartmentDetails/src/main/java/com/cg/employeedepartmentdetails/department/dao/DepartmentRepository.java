package com.cg.employeedepartmentdetails.department.dao;
import java.util.List;
import com.cg.employeedepartmentdetails.dto.Department;
import com.cg.employeedepartmentdetails.dto.Employee;
import com.cg.employeedepartmentdetails.exception.DepartmentNameNotFoundException;
import com.cg.employeedepartmentdetails.exception.IdNotFoundException;

public interface DepartmentRepository {
	public Department save(Department department);
	public List<Employee> findByDepartmentName(String name)throws DepartmentNameNotFoundException;
}
