package com.cg.employeedepartmentdetails.exception;

public class EmployeeNameNotFoundException extends Exception{
	public EmployeeNameNotFoundException() {}
	public EmployeeNameNotFoundException(String msg) {
		super(msg);
	}
}
