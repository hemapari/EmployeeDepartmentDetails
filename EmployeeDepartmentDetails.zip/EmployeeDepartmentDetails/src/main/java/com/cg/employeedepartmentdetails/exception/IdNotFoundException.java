package com.cg.employeedepartmentdetails.exception;

public class IdNotFoundException extends Exception{
	public IdNotFoundException() {}
	public IdNotFoundException(String s) {
		super(s);
	}
}
