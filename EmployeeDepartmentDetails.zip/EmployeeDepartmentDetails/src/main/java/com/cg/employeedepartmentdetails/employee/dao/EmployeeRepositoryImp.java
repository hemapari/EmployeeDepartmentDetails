package com.cg.employeedepartmentdetails.employee.dao;
import java.util.ArrayList;

import java.util.List;
import com.cg.employeedepartmentdetails.dto.Department;
import com.cg.employeedepartmentdetails.dto.Employee;
import com.cg.employeedepartmentdetails.exception.EmployeeNameNotFoundException;
import com.cg.employeedepartmentdetails.exception.IdNotFoundException;
import com.cg.employeedepartmentdetails.util.DBUtil;

public class EmployeeRepositoryImp implements EmployeeRepository {
	
	public Employee save(Employee employee) {
		DBUtil.employeeList.add(employee);
		return employee;}
	
	public Employee findByEmployeeId(int id) throws IdNotFoundException {
		for (Employee employee:DBUtil.employeeList)
			{if(employee.getId()==id)
				return employee;}
	        throw new IdNotFoundException("Id not found!");}
	
	public List<Employee> findByEmployeeName(String name)throws EmployeeNameNotFoundException 
		{ List<Employee> empSearch=new ArrayList();
		for(Employee employee:DBUtil.employeeList) {
			if(employee.getName().equals(name)) 
				empSearch.add(employee);}
		if(empSearch.isEmpty())
			throw new EmployeeNameNotFoundException("Employee Name not found!");
	   return empSearch;}}
		


