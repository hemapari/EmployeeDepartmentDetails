package com.cg.employeedepartmentdetails.employee.service;
import java.util.List;
import com.cg.employeedepartmentdetails.dto.Employee;
import com.cg.employeedepartmentdetails.exception.EmployeeNameNotFoundException;
import com.cg.employeedepartmentdetails.exception.IdNotFoundException;

public interface EmployeeService {
	public Employee addEmployee(Employee employee);
	public Employee updateEmployeeDetails(Employee employee);
	public Employee searchByEmployeeId(int id)throws IdNotFoundException;
	public List<Employee> searchByEmployeeName(String name)throws EmployeeNameNotFoundException;
}
