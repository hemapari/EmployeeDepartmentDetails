package com.cg.JPAEmployeeDepartmentDetails.exception;

public class DepartmentNameNotFoundException extends RuntimeException {
	public DepartmentNameNotFoundException() {}
	public DepartmentNameNotFoundException(String str) {
		super(str);
	}
	
}
