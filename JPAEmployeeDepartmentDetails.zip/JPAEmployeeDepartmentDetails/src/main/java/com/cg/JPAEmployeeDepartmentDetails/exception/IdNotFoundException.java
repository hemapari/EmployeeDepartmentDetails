package com.cg.JPAEmployeeDepartmentDetails.exception;

public class IdNotFoundException extends RuntimeException{
	public IdNotFoundException() {}
	public IdNotFoundException(String s) {
		super(s);
	}
}
