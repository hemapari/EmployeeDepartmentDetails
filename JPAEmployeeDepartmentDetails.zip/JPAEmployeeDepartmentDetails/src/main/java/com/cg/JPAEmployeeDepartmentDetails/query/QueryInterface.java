package com.cg.JPAEmployeeDepartmentDetails.query;

public interface QueryInterface {
	String qry="select d from Department d where d.name= :departmentName";
	String qryOne="FROM Employee  WHERE name=:name";
	String qryTwo="select d.employees from Department d where d.name=:name";
}
