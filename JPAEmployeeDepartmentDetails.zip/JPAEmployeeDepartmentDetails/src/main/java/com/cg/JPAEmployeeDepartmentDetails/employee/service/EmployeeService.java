package com.cg.JPAEmployeeDepartmentDetails.employee.service;
import java.util.List;

import com.cg.JPAEmployeeDepartmentDetails.dto.Employee;
import com.cg.JPAEmployeeDepartmentDetails.exception.EmployeeNameNotFoundException;
import com.cg.JPAEmployeeDepartmentDetails.exception.IdNotFoundException;

public interface EmployeeService {
	public Employee addEmployee(Employee employee)throws IdNotFoundException;
	public Employee updateEmployeeDetails(int id,double salary)throws IdNotFoundException;
	public Employee searchByEmployeeId(int id)throws IdNotFoundException;
	public List<Employee> searchByEmployeeName(String name)throws EmployeeNameNotFoundException;
	
}
