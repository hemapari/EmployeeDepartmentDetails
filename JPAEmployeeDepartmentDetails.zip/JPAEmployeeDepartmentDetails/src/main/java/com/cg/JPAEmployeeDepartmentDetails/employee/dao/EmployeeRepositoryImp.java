package com.cg.JPAEmployeeDepartmentDetails.employee.dao;
import java.util.ArrayList;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.JPAEmployeeDepartmentDetails.dto.Department;
import com.cg.JPAEmployeeDepartmentDetails.dto.Employee;
import com.cg.JPAEmployeeDepartmentDetails.exception.EmployeeNameNotFoundException;
import com.cg.JPAEmployeeDepartmentDetails.exception.IdNotFoundException;
import com.cg.JPAEmployeeDepartmentDetails.query.QueryInterface;
import com.cg.JPAEmployeeDepartmentDetails.util.DbUtil;

public class EmployeeRepositoryImp implements EmployeeRepository {

public static EntityManager em;

	/**Written by Hemavathi on 04-05-2019
	 * last modified on 05-05-2019
	 * This save method is used to save the employee details in the database
	 */
	public Employee save(Employee employee)throws IdNotFoundException
	{
		try {
		em=DbUtil.getConnection();
		Department department=new Department();
		TypedQuery<Department> query=em.createQuery(QueryInterface.qry,Department.class);
		query.setParameter("departmentName",employee.getDepartmentName());
		Department d=query.getSingleResult();
		List<Employee> emp=d.getEmployees();
		emp.add(employee);
		d.setEmployees(emp);
	    em.persist(employee);
	    em.getTransaction().commit();
		return employee;
		}
		catch(Exception e)	{
	
			throw new IdNotFoundException("Id already exist/choose the existing department");
		}
		finally {
			if(em!=null) {
				em.close();
		}}
	}
	
	/**Written by Hemavathi on 04-05-2019
	 * last modified on 05-05-2019
	 * This findByEmployeeId method is used to display the employee details if the particular employee id is found in the database
	 */
	public Employee findByEmployeeId(int id) throws IdNotFoundException 
	{
		em=DbUtil.getConnection();
		
		try {
		return em.find(Employee.class, id);
		}
		catch(Exception e)
		{
			throw new IdNotFoundException("Id not found");
		}
		finally {
			if(em!=null)
				em.close();
		}
		
	}

	/**Written by Hemavathi on 04-05-2019
	 * last modified on 05-05-2019
	 * This findByEmployeeName method is used to display the employee id if the particular employee name is found in the database
	 */
	public List<Employee> findByEmployeeName(String name) throws EmployeeNameNotFoundException
	{
		em=DbUtil.getConnection();
		try {
		Query query=em.createQuery(QueryInterface.qryOne);
		query.setParameter("name",name);		
		List<Employee> empList=query.getResultList();
		return empList;
		}
		catch(Exception e)
		{
			throw new EmployeeNameNotFoundException("Employee name not found");
		}
		finally {
			if(em!=null)
				em.close();
		}
		
		
	}
	
	/**Written by Hemavathi on 04-05-2019
	 * last modified on 05-05-2019
	 * This UpdateEmployee method is used to update the employee salary if the particular employee id is found in the database
	 */
	public Employee updateEmployee(int id,double salary)throws IdNotFoundException {
		em=DbUtil.getConnection();
	    Employee employee=em.find(Employee.class,id);
	    try {
	    if(employee!=null) {
		employee.setSalary(salary);
		 em.getTransaction().commit();}
		return employee;}
	    catch(IdNotFoundException e)
		{
			throw new IdNotFoundException("Id already exist");
		}
		finally {
			if(em!=null)
				em.close();
		}
	
}


	
	}
		


