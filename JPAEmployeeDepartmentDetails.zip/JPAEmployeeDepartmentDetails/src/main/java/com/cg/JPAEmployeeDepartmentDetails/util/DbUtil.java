package com.cg.JPAEmployeeDepartmentDetails.util;

import javax.persistence.EntityManager;


import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class DbUtil {
static EntityManager em=null;
public static EntityManager getConnection() {
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("employeedepartmentdetails");
	em=emf.createEntityManager();
	em.getTransaction().begin();
	return em;
			
}
}
