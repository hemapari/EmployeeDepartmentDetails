package com.cg.JPAEmployeeDepartmentDetails.employee.service;
import java.util.List;

import com.cg.JPAEmployeeDepartmentDetails.department.dao.DepartmentRepository;
import com.cg.JPAEmployeeDepartmentDetails.department.dao.DepartmentRepositoryImp;
import com.cg.JPAEmployeeDepartmentDetails.dto.Employee;
import com.cg.JPAEmployeeDepartmentDetails.employee.dao.EmployeeRepository;
import com.cg.JPAEmployeeDepartmentDetails.employee.dao.EmployeeRepositoryImp;
import com.cg.JPAEmployeeDepartmentDetails.exception.EmployeeNameNotFoundException;
import com.cg.JPAEmployeeDepartmentDetails.exception.IdNotFoundException;

public class EmployeeServiceImp implements EmployeeService {
    EmployeeRepository dao;
	
	public EmployeeServiceImp() {
		dao=new EmployeeRepositoryImp();}
	
	public Employee addEmployee(Employee employee) throws IdNotFoundException{
		Employee emp=dao.save(employee);
		if(emp==null)
			throw new IdNotFoundException("Employee id is already found");
		return emp;
	}

	

	public Employee updateEmployeeDetails(int id,double salary)throws IdNotFoundException {
		return dao.updateEmployee(id, salary);
		
	}
	
	public Employee searchByEmployeeId(int id) throws IdNotFoundException {
		Employee emp=dao.findByEmployeeId(id);
		if(emp==null)
			throw new IdNotFoundException("Employee id not found");
		return emp;
	}

	public List<Employee> searchByEmployeeName(String name)throws EmployeeNameNotFoundException{ 
		List<Employee> emps=dao.findByEmployeeName(name);
		if(emps.isEmpty())
			throw new EmployeeNameNotFoundException("Employee name not found");
		return emps;
	}

	
}
