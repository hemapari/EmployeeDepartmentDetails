package com.cg.JPAEmployeeDepartmentDetails.employee.dao;
import java.util.List;

import com.cg.JPAEmployeeDepartmentDetails.dto.Employee;
import com.cg.JPAEmployeeDepartmentDetails.exception.EmployeeNameNotFoundException;
import com.cg.JPAEmployeeDepartmentDetails.exception.IdNotFoundException;

public interface EmployeeRepository {
	public Employee save(Employee employee)throws IdNotFoundException;
	public Employee updateEmployee(int id,double salary)throws IdNotFoundException;
	public Employee findByEmployeeId(int id)throws IdNotFoundException;
	public List<Employee> findByEmployeeName(String name)throws EmployeeNameNotFoundException;
	
}
