
package com.cg.JPAEmployeeDepartmentDetails.dto;
import java.util.ArrayList;


import java.util.List;
import com.cg.JPAEmployeeDepartmentDetails.dto.Employee;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="department")

public class Department {
	@Id
	@Column(name="d_id")
	private int id;
	@Column(name="d_name")
private String name;
	
@OneToMany(cascade=CascadeType.ALL)
@JoinColumn(name="department_id")
private List<Employee> employees=new ArrayList<Employee>();

public  Department() {}

public Department(String name, int id, List<Employee> employees) {
	super();
	this.name = name;
	this.id = id;
	this.employees = employees;
}



public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}


public List<Employee> getEmployees() {
	return employees;
}

public void setEmployees(List<Employee> employees) {
	this.employees = employees;
}

@Override
public String toString() {
	return "Department [name=" + name + ", id=" + id + ", employees=" + employees + "]";
}

//@OneToMany(cascade=CascadeType.ALL,mappedBy="department")

}
