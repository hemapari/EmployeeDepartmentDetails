package com.cg.JPAEmployeeDepartmentDetails.exception;

public class EmployeeNameNotFoundException extends RuntimeException{
	public EmployeeNameNotFoundException() {}
	public EmployeeNameNotFoundException(String msg) {
		super(msg);
	}
}
