package com.cg.JPAEmployeeDepartmentDetails.department.dao;
import java.util.List;

import com.cg.JPAEmployeeDepartmentDetails.dto.Department;
import com.cg.JPAEmployeeDepartmentDetails.dto.Employee;
import com.cg.JPAEmployeeDepartmentDetails.exception.DepartmentNameNotFoundException;
import com.cg.JPAEmployeeDepartmentDetails.exception.IdNotFoundException;

public interface DepartmentRepository {
	public Department save(Department department)throws DepartmentNameNotFoundException;
	public List<Employee> findByDepartmentName(String name)throws DepartmentNameNotFoundException;
	
}
