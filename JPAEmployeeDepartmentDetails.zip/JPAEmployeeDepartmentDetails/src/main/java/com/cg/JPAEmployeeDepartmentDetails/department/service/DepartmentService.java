package com.cg.JPAEmployeeDepartmentDetails.department.service;
import java.util.List;
import java.util.Map;

import com.cg.JPAEmployeeDepartmentDetails.dto.Department;
import com.cg.JPAEmployeeDepartmentDetails.dto.Employee;
import com.cg.JPAEmployeeDepartmentDetails.exception.DepartmentNameNotFoundException;


public interface DepartmentService {
	public Department addDepartment(Department department)throws DepartmentNameNotFoundException;
	public List<Employee> searchByDepartmentName(String name)throws DepartmentNameNotFoundException;
	
}
