package com.cg.JPAEmployeeDepartmentDetails.dto;

import java.math.BigInteger;


import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.cg.JPAEmployeeDepartmentDetails.dto.Department;

@Entity
@Table(name="employee")
public class Employee {
@Id
private int id;
private String name;
@Column(name="dept_name")
private String departmentName;
private double salary;
private BigInteger mobile;
@OneToOne(cascade=CascadeType.ALL)
private Address address;
/*@ManyToOne(cascade=CascadeType.ALL)
@JoinColumn(name="d_id")
private Department department;
*/

public Employee() {}

public Employee(int id, String name, String departmentName, double salary, BigInteger mobile, Address address) {
	super();
	this.id = id;
	this.name = name;
	this.departmentName = departmentName;
	this.salary = salary;
	this.mobile = mobile;
	this.address = address;
}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getDepartmentName() {
	return departmentName;
}

public void setDepartmentName(String departmentName) {
	this.departmentName = departmentName;
}

public double getSalary() {
	return salary;
}

public void setSalary(double salary) {
	this.salary = salary;
}

public BigInteger getMobile() {
	return mobile;
}

public void setMobile(BigInteger mobile) {
	this.mobile = mobile;
}

public Address getAddress() {
	return address;
}

public void setAddress(Address address) {
	this.address = address;
}

@Override
public String toString() {
	return "Employee [id=" + id + ", name=" + name + ", departmentName=" + departmentName + ", salary=" + salary
			+ ", mobile=" + mobile + ", address=" + address + "]";
}




}
