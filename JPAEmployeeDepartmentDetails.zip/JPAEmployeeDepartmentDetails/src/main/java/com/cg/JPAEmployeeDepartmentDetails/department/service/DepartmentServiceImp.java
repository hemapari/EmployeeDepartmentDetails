package com.cg.JPAEmployeeDepartmentDetails.department.service;
import java.util.List;

import com.cg.JPAEmployeeDepartmentDetails.department.dao.DepartmentRepository;
import com.cg.JPAEmployeeDepartmentDetails.department.dao.DepartmentRepositoryImp;
import com.cg.JPAEmployeeDepartmentDetails.dto.Department;
import com.cg.JPAEmployeeDepartmentDetails.dto.Employee;
import com.cg.JPAEmployeeDepartmentDetails.exception.DepartmentNameNotFoundException;
import com.cg.JPAEmployeeDepartmentDetails.exception.IdNotFoundException;

public class DepartmentServiceImp implements DepartmentService{

	DepartmentRepository dao;
	
	public DepartmentServiceImp() {
		dao=new DepartmentRepositoryImp();

	}

	public Department addDepartment(Department department)throws DepartmentNameNotFoundException {
		return dao.save(department);
	}

	
	public List<Employee> searchByDepartmentName(String name) throws DepartmentNameNotFoundException{
		List<Employee> empp=dao.findByDepartmentName(name);
		//List<Employee> empp=dao.findByDeptName(name);
		if(empp.isEmpty())
		throw new DepartmentNameNotFoundException("Department name is not found");
		return empp;
		//return dao.findByDepartmentName(name);
	}
}
	



