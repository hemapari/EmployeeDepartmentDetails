package com.cg.JPAEmployeeDepartmentDetails.ui;

import java.math.BigDecimal;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import com.cg.JPAEmployeeDepartmentDetails.department.service.DepartmentService;
import com.cg.JPAEmployeeDepartmentDetails.department.service.DepartmentServiceImp;
import com.cg.JPAEmployeeDepartmentDetails.dto.Address;
import com.cg.JPAEmployeeDepartmentDetails.dto.Department;
import com.cg.JPAEmployeeDepartmentDetails.dto.Employee;
import com.cg.JPAEmployeeDepartmentDetails.employee.service.EmployeeService;
import com.cg.JPAEmployeeDepartmentDetails.employee.service.EmployeeServiceImp;
import com.cg.JPAEmployeeDepartmentDetails.exception.DepartmentNameNotFoundException;
import com.cg.JPAEmployeeDepartmentDetails.exception.EmployeeNameNotFoundException;
import com.cg.JPAEmployeeDepartmentDetails.exception.IdNotFoundException;

public class MyApplication {
	
	static EmployeeService service;
	static DepartmentService deptService;
	
	public static void main(String[] args) {
     service= new EmployeeServiceImp();
     deptService=new DepartmentServiceImp();
	 Scanner scr=new Scanner(System.in);
	 Employee emp=new Employee();
	 Department dept;
	 int choice=0;
	 do {
		printDetails(); 
		System.out.println("Enter your choice");
		choice=scr.nextInt();
		switch(choice) {
		
		
		case 1://add department
			dept=new Department();
			System.out.println("Enter the department name");
			String departmentname=scr.next();
			System.out.println("Enter department id");
			int deptId=scr.nextInt();
			dept.setName(departmentname);
			dept.setId(deptId);
			
			try {
				System.out.println(deptService.addDepartment(dept));
				}catch (DepartmentNameNotFoundException e) {System.err.println(e.getMessage());}
			break;
			
		case 2://add employee
			Address address=new Address();
			System.out.println("Enter  the Department Name: ");
			String deptn=scr.next();
			
			System.out.println("Enter Employee Name: ");
			String name=scr.next();
			System.out.println("Enter Employee Id: ");
			int id=scr.nextInt();
			System.out.println("Enter Employee Mobile Number: ");
			BigInteger mobNum=scr.nextBigInteger();
			System.out.println("Enter Employee Salary: ");
			double salary=scr.nextDouble();
			System.out.println("Enter employee city: ");
			String city=scr.next();
			System.out.println("Enter employee state: ");
			String state=scr.next();
			System.out.println("Enter employee pincode: ");
			int pincode=scr.nextInt();
			
			emp.setId(id);
			emp.setName(name);
			emp.setDepartmentName(deptn);
			emp.setMobile(mobNum);
			emp.setSalary(salary);
			address.setCity(city);
			address.setState(state);
			address.setPincode(pincode);
			emp.setAddress(address);
			
			try {
				service.addEmployee(emp);
				   }catch(IdNotFoundException e) {System.err.println(e.getMessage());}
			break;
			
	
			
		case 3://update employee details
			System.out.println("Enter Employee id : ");
		    try {
		    	int eid=scr.nextInt();
			Employee empSearch=service.searchByEmployeeId(eid);
			if(empSearch!=null) {
			System.out.println("Enter Salary to be updated: ");
			double sal=scr.nextDouble();
			empSearch=service.updateEmployeeDetails(eid, sal);
			System.out.println("EMPLOYEE DETAIL");
			System.out.println("ID: "+empSearch.getId());
			System.out.println("Name: "+empSearch.getName());
			System.out.println("DepartmentName: "+empSearch.getDepartmentName());
			System.out.println("Mobile Number: "+empSearch.getMobile());
			System.out.println("Salary: "+empSearch.getSalary());
			System.out.println("Address: "+empSearch.getAddress());
			
			}}catch(IdNotFoundException e) {System.err.println(e.getMessage());}
			break;
			
		case 4://search by employee id
			System.out.println("Enter id : ");
		  try { Employee searchId=service.searchByEmployeeId((scr.nextInt()));
				if(searchId!=null) {
					System.out.println("EMPLOYEE DETAIL");
					System.out.println("ID: "+searchId.getId());
					System.out.println("Name: "+searchId.getName());
					System.out.println("DepartmentName: "+searchId.getDepartmentName());
					System.out.println("Mobile Number: "+searchId.getMobile());
					System.out.println("Salary: "+searchId.getSalary());
					System.out.println("Address: "+searchId.getAddress());}}
			catch(IdNotFoundException e){System.err.println(e.getMessage());}
			break;
			
		case 5://search by employee name
				System.out.println("Enter the Employee Name");
				String ename = scr.next();
			   try {List<Employee> empSearch = service.searchByEmployeeName(ename);
					Set<Employee> empSearchOne = new LinkedHashSet<Employee>(empSearch);
					empSearch.clear();
					empSearch.addAll(empSearchOne);
					for (Employee empAll : empSearch)
						System.out.println("Id of the employee " + empAll.getName() + " is " + empAll.getId());}
				catch (EmployeeNameNotFoundException e) {System.err.println(e.getMessage());}
				break;
			
	    case 6://search by department name
				System.out.println("Enter the Department Name");
				String departmentName = scr.next();
			  try { List<Employee> deptSearch = deptService.searchByDepartmentName(departmentName);
					System.out.println("Employee(s) under " + departmentName + " department ");
					Set<Employee> deptSearchOne = new LinkedHashSet<Employee>(deptSearch);
					deptSearch.clear();
					deptSearch.addAll(deptSearchOne);
					for (Employee employees : deptSearch)
						System.out.println("Id: " + employees.getId() + ", Name: " + employees.getName());}
			  catch (DepartmentNameNotFoundException e) {System.err.println(e.getMessage());}
				break;
			
		default:
			System.out.println("You are exited");
			break;
		}}while(choice!=7);}
	
public static void printDetails() {
		
		System.out.println("1. Add Department");
		System.out.println("2. Add Employee");
		System.out.println("3. Update Employee Details");
		System.out.println("4. Search By EmployeeId");
		System.out.println("5. Search By EmployeeName ");
		System.out.println("6. Search By DepartmentName");
		System.out.println("7. Exit");}
}
