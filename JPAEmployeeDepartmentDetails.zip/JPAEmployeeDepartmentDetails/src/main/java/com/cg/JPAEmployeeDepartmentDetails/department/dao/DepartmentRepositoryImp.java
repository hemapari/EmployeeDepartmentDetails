package com.cg.JPAEmployeeDepartmentDetails.department.dao;
import java.util.ArrayList;





import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.JPAEmployeeDepartmentDetails.dto.Department;
import com.cg.JPAEmployeeDepartmentDetails.dto.Employee;
import com.cg.JPAEmployeeDepartmentDetails.exception.DepartmentNameNotFoundException;
import com.cg.JPAEmployeeDepartmentDetails.query.QueryInterface;
import com.cg.JPAEmployeeDepartmentDetails.util.DbUtil;

public class DepartmentRepositoryImp implements DepartmentRepository {
	
public static EntityManager em;

/**Written by Hemavathi on 04-05-2019
 * last modified on 05-05-2019
 * This save method is used to save the department in the database
 */

	public Department save(Department department)throws DepartmentNameNotFoundException {
		
		try {
			em=DbUtil.getConnection();
		em.persist(department);
		em.getTransaction().commit();
		return department;
	    }
	    catch(Exception e)	
		{throw new DepartmentNameNotFoundException("Department name already exist");}
		finally {
		if(em!=null)
			em.close();
	}
		
	}
	
	
	/**Written by Hemavathi on 04-05-2019
	 * last modified on 05-05-2019
	 * This findByDepartmentName method is used to list the id and name of the employees under the department if the particular department name is found in the database
	 */
	public List<Employee> findByDepartmentName(String name) throws DepartmentNameNotFoundException {
		em=DbUtil.getConnection();
		try {
		Query query=em.createQuery(QueryInterface.qryTwo);
		query.setParameter("name",name);
		List<Employee> list=query.getResultList();
		return list;
		
		}
		catch(Exception e)	
		{throw new DepartmentNameNotFoundException("Department name not found");}
		finally {
		if(em!=null)
			em.close();
	}
		
	}



	

	
}
