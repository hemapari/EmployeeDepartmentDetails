package com.cg.employeedepartmentdetailsspringmvc.controller;

import java.util.ArrayList;


import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.employeedepartmentdetailsspringmvc.department.service.DepartmentService;
import com.cg.employeedepartmentdetailsspringmvc.dto.Department;
import com.cg.employeedepartmentdetailsspringmvc.dto.Employee;
import com.cg.employeedepartmentdetailsspringmvc.employee.service.EmployeeService;
import com.cg.employeedepartmentdetailsspringmvc.exception.DepartmentNameNotFoundException;
import com.cg.employeedepartmentdetailsspringmvc.exception.EmployeeNameNotFoundException;
import com.cg.employeedepartmentdetailsspringmvc.exception.IdNotFoundException;

/**Written by Hemavathi on 20-05-2019
 * last modified on 22-05-2019
 *The class MyController links to the jsp pages through @GetMapping and @PostMapping 
 */
@Controller
public class MyController {
@Autowired
EmployeeService empService;
@Autowired
DepartmentService deptService;
	
@GetMapping("begin")  
public String listPage() {
	return "empdeptlist";    
}

@GetMapping("addemployee")
public ModelAndView getEmployee(@ModelAttribute("emp")Employee employee)
{return new ModelAndView("employee");}
	
@PostMapping("addemp")
public ModelAndView addEmployee(@ModelAttribute("emp")Employee employee)
{  
	Employee emp=empService.addEmployee(employee);
	return new ModelAndView("success","key",emp);
	}


@GetMapping("adddept")
public ModelAndView getDepartment(@ModelAttribute("dept")Employee department)
{	return new ModelAndView("department");}

@PostMapping("adddepartment")
public ModelAndView addDepartment(@ModelAttribute("dept")Department department) throws DepartmentNameNotFoundException
{   
	Department deptmt=deptService.addDepartment(department);
	return new ModelAndView("successPage","key",deptmt);
	}


@GetMapping("searchbyempid")
public ModelAndView getsearchEmployeeById(@ModelAttribute("emp") Employee employee) {
	return new ModelAndView("search");
}

@PostMapping("searchemployee")
@ExceptionHandler(IdNotFoundException.class)
public ModelAndView searchEmployeeById(@ModelAttribute("emp") Employee employee)
{
	
	Employee myEmployee;
	try {
		myEmployee = empService.searchByEmployeeId(employee.getId());
		return new ModelAndView("searchdetails","showemployee", myEmployee);
	} catch (IdNotFoundException e) {
		// TODO Auto-generated catch block
		return new ModelAndView("error");
	}
	
}

@GetMapping("searchbyempname")
public ModelAndView getsearchEmployeeByName(@ModelAttribute("emp") Employee employee) 
{
	return new ModelAndView("searchEmpName");
}


@PostMapping("searchemployeename")
@ExceptionHandler(EmployeeNameNotFoundException.class)
public ModelAndView searchEmployeeByName(ModelAndView model,@ModelAttribute("emp") Employee employee)
{
	List<Employee> myEmployee;
	try {
		myEmployee = empService.searchByEmployeeName(employee.getName());
		model.addObject("showemployee", myEmployee);
		model.setViewName("empsearchdetails");
		return model;
	} catch (EmployeeNameNotFoundException e) {
		// TODO Auto-generated catch block
		return new ModelAndView("errortwo");
	}
	
}
@GetMapping("updateemployee")
public ModelAndView toUpdate(@ModelAttribute("emp") Employee employee) {
	return new ModelAndView("modifyform");
}


@PostMapping("modifyemployee")
@ExceptionHandler(IdNotFoundException.class)
public ModelAndView modifyEmployee(@ModelAttribute("emp") Employee employee)
{
	Employee emp;
	try {
		emp = empService.updateEmployeeDetails(employee.getId(),employee.getSalary());
		return new ModelAndView("changes","showemployee", emp);
	} catch (IdNotFoundException e) {
		// TODO Auto-generated catch block
		return new ModelAndView("error");
	}
	
}	
@GetMapping("searchbydeptname")
public ModelAndView getsearchDepartmentByName(@ModelAttribute("dept") Department department) {
	return new ModelAndView("searchDeptName");
}


@PostMapping("searchdepartmentname")
@ExceptionHandler(DepartmentNameNotFoundException.class)
public ModelAndView searchDepartmentByName(ModelAndView model,@ModelAttribute("dept") Department department) 
{
	List<Employee> myEmployee;
	try {
		myEmployee = deptService.searchByDepartmentName(department.getName());
		model.addObject("showemployee", myEmployee);
		model.setViewName("deptsearchdetails");
		return model;
	} catch (DepartmentNameNotFoundException e) {
		// TODO Auto-generated catch block
		return new ModelAndView("errorthree");
	}
	
}
@GetMapping("home")
public String homePage() {
	return "empdeptlist";   
}



}


