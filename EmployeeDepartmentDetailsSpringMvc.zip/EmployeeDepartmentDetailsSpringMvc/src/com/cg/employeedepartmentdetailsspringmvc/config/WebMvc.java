package com.cg.employeedepartmentdetailsspringmvc.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.view.JstlView;
/**Written by Hemavathi on 20-05-2019
 * last modified on 22-05-2019
 * The class ApplicationInitializer acts like a dispatcher-servlet.xml
 */
@Configuration
@EnableWebMvc  
@ComponentScan("com.cg.employeedepartmentdetailsspringmvc")
public class WebMvc implements WebMvcConfigurer
{
	
    @Bean  
	public InternalResourceViewResolver getAllView() {
		InternalResourceViewResolver viewResource=new  InternalResourceViewResolver();
		viewResource.setViewClass(JstlView.class);
		viewResource.setPrefix("/WEB-INF/pages/");
		viewResource.setSuffix(".jsp");
		return viewResource;
	}
	
	
}
