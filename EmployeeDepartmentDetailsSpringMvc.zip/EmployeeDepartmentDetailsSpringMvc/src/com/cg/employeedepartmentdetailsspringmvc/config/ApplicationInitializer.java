package com.cg.employeedepartmentdetailsspringmvc.config;

import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

/**Written by Hemavathi on 20-05-2019
 * last modified on 22-05-2019
 * The class ApplicationInitializer acts like a web.xml 
 */
public class ApplicationInitializer extends AbstractAnnotationConfigDispatcherServletInitializer
{
	

	@Override
	protected Class<?>[] getRootConfigClasses() {
		// TODO Auto-generated method stub
		return new Class[] {AppContext.class};
	}

	@Override
	protected Class<?>[] getServletConfigClasses() {
		// TODO Auto-generated method stub
		return new Class[] {WebMvc.class}; 
	}

	@Override
	protected String[] getServletMappings() {
		// TODO Auto-generated method stub
		return new String[] {"/"};  
	}

}
