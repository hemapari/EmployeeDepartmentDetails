package com.cg.employeedepartmentdetailsspringmvc.employee.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.employeedepartmentdetailsspringmvc.department.dao.DepartmentRepository;
import com.cg.employeedepartmentdetailsspringmvc.department.dao.DepartmentRepositoryImp;
import com.cg.employeedepartmentdetailsspringmvc.dto.Department;
import com.cg.employeedepartmentdetailsspringmvc.dto.Employee;
import com.cg.employeedepartmentdetailsspringmvc.employee.dao.EmployeeRepository;
import com.cg.employeedepartmentdetailsspringmvc.employee.dao.EmployeeRepositoryImp;
import com.cg.employeedepartmentdetailsspringmvc.exception.EmployeeNameNotFoundException;
import com.cg.employeedepartmentdetailsspringmvc.exception.IdNotFoundException;
/**Written by Hemavathi on 20-05-2019
 * last modified on 22-05-2019
 * The class EmployeeServiceImpis the bean which implements the methods of EmployeeService
 */
@Service
@Transactional
public class EmployeeServiceImp implements EmployeeService {

	@Autowired
	EmployeeRepository empdao;
	
	/**Written by Hemavathi on 20-05-2019
	 * last modified on 22-05-2019
	 * This method addEmployee links to the dao layer save method
	 */
	@Override
	public Employee addEmployee(Employee employee)
	{
		// TODO Auto-generated method stub
		return empdao.save(employee);
		
	}
	
	/**Written by Hemavathi on 20-05-2019
	 * last modified on 22-05-2019
	 * This method updateEmployeeDetails links to the dao layer updateEmployee method
	 */
	@Override
	public Employee updateEmployeeDetails(int id,double salary)throws IdNotFoundException 
	{
		// TODO Auto-generated method stub
		Employee emp=empdao.updateEmployee(id, salary);
		if(emp==null)
			throw new IdNotFoundException("Employee id not found");
		return emp;
	}
	
	/**Written by Hemavathi on 20-05-2019
	 * last modified on 22-05-2019
	 * This method searchByEmployeeId links to the dao layer findByEmployeeId method
	 */
	@Override
	public Employee searchByEmployeeId(int id) throws IdNotFoundException
	{
		// TODO Auto-generated method stub
		Employee emp=empdao.findByEmployeeId(id);
		if(emp==null)
			throw new IdNotFoundException("Employee id not found");
		return emp;
	}
	
	/**Written by Hemavathi on 20-05-2019
	 * last modified on 22-05-2019
	 *  This method searchByEmployeeName links to the dao layer findByEmployeeName method
	 */
	@Override
	public List<Employee> searchByEmployeeName(String name) throws EmployeeNameNotFoundException 
	{
		// TODO Auto-generated method stub
		//return empdao.findByEmployeeName(name);
		List<Employee> emps=empdao.findByEmployeeName(name);
		if(emps.isEmpty())
			throw new EmployeeNameNotFoundException("Employee name not found");
		return emps;
	}
   

}
