package com.cg.employeedepartmentdetailsspringmvc.employee.service;
import java.util.List;


import com.cg.employeedepartmentdetailsspringmvc.dto.Employee;
import com.cg.employeedepartmentdetailsspringmvc.exception.EmployeeNameNotFoundException;
import com.cg.employeedepartmentdetailsspringmvc.exception.IdNotFoundException;

/**Written by Hemavathi on 20-05-2019
 * last modified on 22-05-2019
 * The interface EmployeeService declares the methods
 */
public interface EmployeeService {
	public Employee addEmployee(Employee employee);
	public Employee updateEmployeeDetails(int id,double salary)throws IdNotFoundException;
	public Employee searchByEmployeeId(int id)throws IdNotFoundException;
	public List<Employee> searchByEmployeeName(String name)throws EmployeeNameNotFoundException;
}
