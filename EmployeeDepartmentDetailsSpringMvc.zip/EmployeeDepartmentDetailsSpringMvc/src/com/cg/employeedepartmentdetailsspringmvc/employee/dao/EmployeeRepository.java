package com.cg.employeedepartmentdetailsspringmvc.employee.dao;
import java.util.List;


import com.cg.employeedepartmentdetailsspringmvc.dto.Employee;
import com.cg.employeedepartmentdetailsspringmvc.exception.EmployeeNameNotFoundException;
import com.cg.employeedepartmentdetailsspringmvc.exception.IdNotFoundException;
/**Written by Hemavathi on 20-05-2019
 * last modified on 22-05-2019
 * The interface EmployeeRepository declares the methods
 */
public interface EmployeeRepository {
	public Employee save(Employee employee);
	public Employee updateEmployee(int id,double salary);
	public Employee findByEmployeeId(int id);
	public List<Employee> findByEmployeeName(String name);
}
