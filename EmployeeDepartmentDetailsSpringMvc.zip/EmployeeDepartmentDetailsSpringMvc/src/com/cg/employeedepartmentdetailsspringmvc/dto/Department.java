package com.cg.employeedepartmentdetailsspringmvc.dto;
import java.util.List;


import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**Written by Hemavathi  on 20-05-2019
 * last modified on 22-05-2019
 * The class Department is the bean which contains description about Department
 */
@Entity
@Table(name="department")

public class Department {
	@Id
	@Column(name="d_id")
	private Integer id;
	@Column(name="d_name")
private String name;
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name="department_id")
private List<Employee> employees;

public  Department() {}

public Department(String name, Integer id, List<Employee> employees) {
	super();
	this.name = name;
	this.id = id;
	this.employees = employees;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public Integer getId() {
	return id;
}

public void setId(Integer id) {
	this.id = id;
}

public List<Employee> getEmployees() {
	return employees;
}

public void setEmployees(List<Employee> employees) {
	this.employees = employees;
}

@Override
public String toString() {
	return "Department [name=" + name + ", id=" + id + ", employees=" + employees + "]";
}



}
