package com.cg.employeedepartmentdetailsspringmvc.exception;
/**Written by Hemavathi on 20-05-2019
 * last modified on 22-05-2019
 * The class DepartmentNameNotFoundException is the exception class ,it is thrown when name of the department is not found
 */
public class DepartmentNameNotFoundException extends Exception {
	public DepartmentNameNotFoundException() {}
	public DepartmentNameNotFoundException(String str) {
		super(str);
	}
	
}
