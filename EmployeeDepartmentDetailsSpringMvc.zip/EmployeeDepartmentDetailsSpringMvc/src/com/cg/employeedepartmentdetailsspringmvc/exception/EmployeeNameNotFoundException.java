package com.cg.employeedepartmentdetailsspringmvc.exception;
/**Written by Hemavathi on 20-05-2019
 * last modified on 22-05-2019
 * The class EmployeeNameNotFoundException is the exception class ,it is thrown when name of the employee is not found
 */
public class EmployeeNameNotFoundException extends Exception{
	public EmployeeNameNotFoundException() {}
	public EmployeeNameNotFoundException(String msg) {
		super(msg);
	}
}
