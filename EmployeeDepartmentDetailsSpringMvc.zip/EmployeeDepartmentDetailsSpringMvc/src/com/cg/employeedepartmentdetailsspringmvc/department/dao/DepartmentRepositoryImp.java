package com.cg.employeedepartmentdetailsspringmvc.department.dao;
import java.util.ArrayList;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.employeedepartmentdetailsspringmvc.dto.Department;
import com.cg.employeedepartmentdetailsspringmvc.dto.Employee;
import com.cg.employeedepartmentdetailsspringmvc.exception.DepartmentNameNotFoundException;
import com.cg.employeedepartmentdetailsspringmvc.query.QueryInterface;
/**Written by Hemavathi  on 20-05-2019
 * last modified on 22-05-2019
 * This class DepartmentRepositoryImp implements the methods of DepartmentRepository
 */
@Repository
public class DepartmentRepositoryImp implements DepartmentRepository {
	@PersistenceContext
	EntityManager em;
	/**Written by Hemavathi on 20-05-2019
	 * last modified on 22-05-2019
	 * This save method is used to save the department in the database
	 */
	@Override
	public Department save(Department department) 
	{
		
		try {
		em.persist(department);
		em.flush();
		//return department;
	    }
	    catch(Exception e)	
		{
	}
		return department;}


	/**Written by Hemavathi on 20-05-2019
	 * last modified on 22-05-2019
	 * This findByDepartmentName method is used to list the id and name of the employees under the department if the particular department name is found in the database
	 */
	@Override
	public List<Employee> findByDepartmentName(String name)
	{
		
	   try {
			Query query=em.createQuery(QueryInterface.qryTwo);
			query.setParameter("name",name);
			List<Employee> list=query.getResultList();
			return list;
			
			}
			catch(Exception e)	{
			}
	return null;
	}

	
}





