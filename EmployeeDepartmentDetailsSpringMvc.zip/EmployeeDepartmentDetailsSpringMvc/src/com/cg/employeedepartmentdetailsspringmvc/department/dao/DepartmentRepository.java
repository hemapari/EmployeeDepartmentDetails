package com.cg.employeedepartmentdetailsspringmvc.department.dao;
import java.util.List;

import com.cg.employeedepartmentdetailsspringmvc.dto.Department;
import com.cg.employeedepartmentdetailsspringmvc.dto.Employee;
import com.cg.employeedepartmentdetailsspringmvc.exception.DepartmentNameNotFoundException;


/**Written by Hemavathi  on 20-05-2019
 * last modified on 22-05-2019
 * The interface DepartmentRepository declares the methods
 */
public interface DepartmentRepository {
	public Department save(Department department);
	public List<Employee> findByDepartmentName(String name);
}
