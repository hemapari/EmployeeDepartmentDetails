package com.cg.employeedepartmentdetailsspringmvc.department.service;
import java.util.List;


import java.util.Map;

import com.cg.employeedepartmentdetailsspringmvc.dto.Department;
import com.cg.employeedepartmentdetailsspringmvc.dto.Employee;
import com.cg.employeedepartmentdetailsspringmvc.exception.DepartmentNameNotFoundException;

/**Written by Hemavathi  on 20-05-2019
 * last modified on 22-05-2019
 * The interface DepartmentService declares the methods
 */
public interface DepartmentService {
	public Department addDepartment(Department department)throws DepartmentNameNotFoundException ;
	public List<Employee> searchByDepartmentName(String name)throws DepartmentNameNotFoundException;
}
