package com.cg.employeedepartmentdetailsspringmvc.department.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.employeedepartmentdetailsspringmvc.department.dao.DepartmentRepository;
import com.cg.employeedepartmentdetailsspringmvc.department.dao.DepartmentRepositoryImp;
import com.cg.employeedepartmentdetailsspringmvc.dto.Department;
import com.cg.employeedepartmentdetailsspringmvc.dto.Employee;
import com.cg.employeedepartmentdetailsspringmvc.exception.DepartmentNameNotFoundException;
import com.cg.employeedepartmentdetailsspringmvc.exception.IdNotFoundException;
/**Written by Hemavathi on 20-05-2019
 * last modified on 22-05-2019
 * The interface DepartmentServiceImp implements the methods of DepartmentService
 */
@Service
@Transactional
public class DepartmentServiceImp implements DepartmentService{

	@Autowired
	DepartmentRepository deptdao;
	
	/**Written by Hemavathi on 20-05-2019
	 * last modified on 22-05-2019
	 * This method addDepartment links to the dao layer save method
	 */
	@Override
	public Department addDepartment(Department department)throws DepartmentNameNotFoundException 
	{
		// TODO Auto-generated method stub
		return deptdao.save(department);
	}
	
	/**Written by Hemavathi  on 20-05-2019
	 * last modified on 22-05-2019
	 * This method searchByDepartmentName links to the dao layer findByDepartmentName method
	 */
	@Override
	public List<Employee> searchByDepartmentName(String name)throws DepartmentNameNotFoundException 
	{
		// TODO Auto-generated method stub
		List<Employee> empp= deptdao.findByDepartmentName(name);
		if(empp.isEmpty())
			throw new DepartmentNameNotFoundException("Department name is not found");
			return empp;
	}

	
	
}
	



