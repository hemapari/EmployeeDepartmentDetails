package com.cg.employeedepartmentdetailsspringmvc.query;
/**Written by Hemavathi on 20-05-2019
 * last modified on 22-05-2019
 * The interface QueryInterface contains the queries which is used in EmployeeRepositoryImpl and DepartmentRepositoryImpl
 */
public interface QueryInterface {
	String qry="select d from Department d where d.name= :departmentName";
	String qryOne="FROM Employee  WHERE name=:name";
	String qryTwo="select d.employees from Department d where d.name=:name";

}
