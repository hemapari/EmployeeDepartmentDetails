package com.cg.BootEmployeeDepartmentDetails.dto;

import java.math.BigInteger;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
/**@author Hemavathi
 * Wrote on 24-05-2019
 * last modified on 25-05-2019
 * The class Employee is the bean which contains description about Employee
 */
@Entity
public class Employee {
	@Id
	private Integer id;
	private String name;
	@Column(name="dept_name")
	private String departmentName;
	private Double salary;
	private BigInteger mobile;
	@OneToOne(cascade=CascadeType.ALL)
	private Address address;
  
	public Employee() {}

	public Employee(Integer id, String name, String departmentName, Double salary, BigInteger mobile, Address address) {
	super();
	this.id = id;
	this.name = name;
	this.departmentName = departmentName;
	this.salary = salary;
	this.mobile = mobile;
	this.address = address;
}
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public Double getSalary() {
		return salary;
	}

	public void setSalary(Double salary) {
		this.salary = salary;
	}

	public BigInteger getMobile() {
		return mobile;
	}

	public void setMobile(BigInteger mobile) {
		this.mobile = mobile;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", departmentName=" + departmentName + ", salary=" + salary
				+ ", mobile=" + mobile + ", address=" + address + "]";
	}

}


/* @ManyToOne(cascade=CascadeType.ALL)
@JoinColumn(name="dept_id")
Department department;*/
/*public Department getDepartment() {
return department;
}
public void setDepartment(Department department) {
this.department = department;
}*/

