package com.cg.BootEmployeeDepartmentDetails.service;

import java.util.ArrayList;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.BootEmployeeDepartmentDetails.controller.EDDController;
import com.cg.BootEmployeeDepartmentDetails.dao.DepartmentDao;
import com.cg.BootEmployeeDepartmentDetails.dto.Department;
import com.cg.BootEmployeeDepartmentDetails.dto.Employee;
import com.cg.BootEmployeeDepartmentDetails.exception.DepartmentNameNotFoundException;

/**@author Hemavathi
 * Wrote on 24-05-2019
 * last modified on 25-05-2019
 * class used to perform business logic on object and interact with DepartmentDao to perform curd operation
 */
@Service
public class DepartmentServiceImpl implements DepartmentService {

	
	@Autowired
	DepartmentDao deptdao;
	
	/**@author Hemavathi
     * Wrote on 24-05-2019
	 * last modified on 25-05-2019
	 * interact DepartmentDao to persist employee object
	 *  @param com.cg.BootEmployeeDepartmentDetails.dto.Department
	 *  @return com.cg.BootEmployeeDepartmentDetails.dto.Department
	 */
	@Override
	public Department addDepartment(Department department) {
		if(EDDController.logger.isDebugEnabled()){
		EDDController.logger.debug("addDepartmentService  addDepartment(Department) is executed!");
	}
		return deptdao.save(department);
	}
	
	/**@author Hemavathi
     * Wrote on 24-05-2019
	 * last modified on 25-05-2019
	 *interact with DepartmentDao to retrieve the records using Department name
	 *  @param name java.lang.String
	 *  @return Department
	 *  @throws com.cg.BootEmployeeDepartmentDetails.exception.DepartmentNameNotFoundException if data not found
	
	 */
	@Override
	public Department searchByDepartmentName(String name) throws DepartmentNameNotFoundException{
		//return deptdao.findByName(name);
		if(EDDController.logger.isDebugEnabled()){
		EDDController.logger.debug("addDepartmentService searchByDepartmentName(String) is executed!");
	}
		Department department= deptdao.findByName(name);
		if(department==null)
		{	EDDController.logger.error(new DepartmentNameNotFoundException());
			throw new DepartmentNameNotFoundException("Department name is not found");
		}
			return department;
	}

}
