

package com.cg.BootEmployeeDepartmentDetails.controller;

import java.util.ArrayList;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.BootEmployeeDepartmentDetails.dto.Department;
import com.cg.BootEmployeeDepartmentDetails.dto.Employee;
import com.cg.BootEmployeeDepartmentDetails.exception.DepartmentNameNotFoundException;
import com.cg.BootEmployeeDepartmentDetails.exception.EmployeeNameNotFoundException;
import com.cg.BootEmployeeDepartmentDetails.exception.IdNotFoundException;
import com.cg.BootEmployeeDepartmentDetails.service.DepartmentService;
import com.cg.BootEmployeeDepartmentDetails.service.EmployeeService;


import org.apache.log4j.Logger;
/**
 * @author Hemavathi
 * Wrote on 24-05-2019
 * last modified on 25-05-2019
 *EDDController is the controller class
 */
@RestController
@RequestMapping("/empdeptdetails")
public class EDDController {
	
	public static final Logger logger = Logger.getLogger(EDDController.class);
	
@Autowired
EmployeeService empservice;
@Autowired
DepartmentService deptservice;

@RequestMapping(value="/adddepartment",method=RequestMethod.POST)
public  ResponseEntity<Department> addDepartment(@ModelAttribute Department department) {
	System.out.println(department);
Department dept=deptservice.addDepartment(department);
	return new ResponseEntity<Department>(dept, HttpStatus.OK);
}

@RequestMapping(value="/addemployee",method=RequestMethod.POST)
public  ResponseEntity<Department> addEmployee(@ModelAttribute Employee employee) {
	String dep_name= employee.getDepartmentName();
	Department department;
	try {
		department = deptservice.searchByDepartmentName(dep_name);
	} catch (DepartmentNameNotFoundException e) {
		return new ResponseEntity(e.getMessage(),HttpStatus.NOT_FOUND);
	}
	List<Employee> employees = department.getEmployees();
	employees.add(employee);
	department.setEmployees(employees);
	Department dep = deptservice.addDepartment(department);
	
	return new ResponseEntity<Department>(dep, HttpStatus.OK);
}

@RequestMapping(value="/searchbyempid/{id}",method=RequestMethod.GET)
public ResponseEntity<Employee> findbyEmployeeId(@PathVariable("id")int id) {
	Employee emp;
	try {
		emp = empservice.searchByEmployeeId(id);
	} catch (IdNotFoundException e) {
		return new ResponseEntity(e.getMessage(),HttpStatus.NOT_FOUND);
	}
	return new ResponseEntity<Employee>(emp,HttpStatus.OK);
	
}
@RequestMapping(value="/searchByEmpName/{name}",method=RequestMethod.GET)
public ResponseEntity<List<Employee>> findByEmployeeName(@PathVariable("name") String name) {
	List<Employee> myList;
	try {
		myList = empservice.searchByEmployeeName(name);
	} catch (EmployeeNameNotFoundException e) {
		return new ResponseEntity(e.getMessage(),HttpStatus.NOT_FOUND);
	}
	return new ResponseEntity<List<Employee>>(myList, HttpStatus.OK);
	
}

@RequestMapping(value="/searchByDeptName/{name}",method=RequestMethod.GET)
public ResponseEntity<Department> findByDepartmentName(@PathVariable("name") String name) {
	Department department;
	try {
		department = deptservice.searchByDepartmentName(name);
	} catch (DepartmentNameNotFoundException e) {
		return new ResponseEntity(e.getMessage(),HttpStatus.NOT_FOUND);
	}
	return new ResponseEntity<Department>(department, HttpStatus.OK);
}

@PutMapping("/update/{id}/{salary}")
public ResponseEntity<Employee> updateEmployee(@PathVariable("id")int id,@PathVariable("salary")double salary) {
	Employee emp;
	try {
		emp = empservice.updateEmployee(id, salary);
	} catch (IdNotFoundException e) {
		// TODO Auto-generated catch block
		return new ResponseEntity(e.getMessage(),HttpStatus.NOT_FOUND);
		//e.printStackTrace();
	}
	if(emp.getId()==id)
		emp.setSalary(salary);
	empservice.addEmployee(emp);
	return new ResponseEntity<Employee>(emp, HttpStatus.OK);
}
}



