package com.cg.BootEmployeeDepartmentDetails.exception;
/**@author Hemavathi
 * Wrote on 24-05-2019
 * last modified on 25-05-2019
 * The class IdNotFoundException is the exception class ,it is thrown when id of the employee is not found in database
 */
public class IdNotFoundException extends Exception{
	public IdNotFoundException() {}
	public IdNotFoundException(String s) {
		super(s);
	}
}
