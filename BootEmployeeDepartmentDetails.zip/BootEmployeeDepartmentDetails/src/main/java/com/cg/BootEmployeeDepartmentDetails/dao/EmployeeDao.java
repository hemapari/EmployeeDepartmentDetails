package com.cg.BootEmployeeDepartmentDetails.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.BootEmployeeDepartmentDetails.dto.Employee;
/**@author Hemavathi
 * Wrote on 24-05-2019
 * last modified on 22-05-2019
 * This interface EmployeeDao declares the methods,which extends JpaRepository
 */
public interface EmployeeDao extends JpaRepository<Employee, Integer> {
	public Employee findById(int id);
	public List<Employee> findByName(String name);
}
