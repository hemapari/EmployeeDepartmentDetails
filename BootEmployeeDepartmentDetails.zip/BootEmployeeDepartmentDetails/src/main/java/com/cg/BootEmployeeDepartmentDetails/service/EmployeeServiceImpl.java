package com.cg.BootEmployeeDepartmentDetails.service;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.BootEmployeeDepartmentDetails.controller.EDDController;
import com.cg.BootEmployeeDepartmentDetails.dao.EmployeeDao;
import com.cg.BootEmployeeDepartmentDetails.dto.Employee;
import com.cg.BootEmployeeDepartmentDetails.exception.EmployeeNameNotFoundException;
import com.cg.BootEmployeeDepartmentDetails.exception.IdNotFoundException;

/**@author Hemavathi
 * Wrote on 24-05-2019
 * last modified on 25-05-2019
 * class used to perform business logic on object and interact with EmployeeDao to perform curd operation
 */
@Service
public class EmployeeServiceImpl implements EmployeeService{

	
	@Autowired
	EmployeeDao empdao;
	
	
	/**@author Hemavathi
     * Wrote on 24-05-2019
	 * last modified on 25-05-2019
	 * interact EmployeeDao to persist employee object
	 * @param com.cg.BootEmployeeDepartmentDetails.dto.Employee
	 * @return com.cg.BootEmployeeDepartmentDetails.dto.Employee
	 */
	@Override
	public Employee addEmployee(Employee employee) {
		if(EDDController.logger.isDebugEnabled()){
		EDDController.logger.debug("addEmployeeService  addEmployee(Employee) is executed!");
	}
		return empdao.save(employee);
	}
	
	
	/**@author Hemavathi
     * Wrote on 24-05-2019
	 * last modified on 25-05-2019
	 *interact with EmployeeDao to retrieve the records using Employee id
	 *@param id int
	 *  @return Employee
	 *  @throws com.cg.BootEmployeeDepartmentDetails.exception.IdNotFoundException if data not found
	 */
	@Override
	public Employee searchByEmployeeId(int id) throws IdNotFoundException {
		if(EDDController.logger.isDebugEnabled()){
		EDDController.logger.debug("addEmployeeService  searchByEmployeeId(int) is executed!");
	}
		Employee emp=empdao.findById(id);
		if(emp==null)
		{	EDDController.logger.error(new IdNotFoundException());
			throw new IdNotFoundException("Employee id not found");}
		return emp;
	}
	
	/**@author Hemavathi
     * Wrote on 24-05-2019
	 * last modified on 25-05-2019
	 * interact with EmployeeDao to retrieve the records using Employee id
	 *@param name java.lang.String
	 * @return List<Employee>
	 * @throws com.cg.BootEmployeeDepartmentDetails.exception.EmployeeNameNotFoundException if data not found
	 */
	@Override
	public List<Employee> searchByEmployeeName(String name) throws EmployeeNameNotFoundException {
		if(EDDController.logger.isDebugEnabled()){
		EDDController.logger.debug("addEmployeeService searchByEmployeeName(String) is executed!");
	}
		List<Employee> emps=empdao.findByName(name);
		if(emps.isEmpty())
		{EDDController.logger.error(new EmployeeNameNotFoundException());
			throw new EmployeeNameNotFoundException("Employee name not found");}
		return emps;
	}

	/**@author Hemavathi
     * Wrote on 24-05-2019
	 * last modified on 25-05-2019
	 *interact with EmployeeDao to update the records using Employee id
	 *@param id int,double salary
	 *  @return Employee
	 *  @throws com.cg.BootEmployeeDepartmentDetails.exception.IdNotFoundException if data not found
	 */
	@Override
	public Employee updateEmployee(int id, double salary) throws IdNotFoundException {
		// TODO Auto-generated method stub
		if(EDDController.logger.isDebugEnabled()){
			EDDController.logger.debug("addEmployeeService updateEmployee(int id, double salary) is executed!");
		}
		Employee emp=empdao.findById(id);
		if(emp==null)
		{	EDDController.logger.error(new IdNotFoundException());
			throw new IdNotFoundException("Employee id not found");}
		return emp;
		
	}
}
