package com.cg.BootEmployeeDepartmentDetails;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
/**
 * @author Hemavathi
 * Wrote on 24-05-2019
 * last modified on 25-05-2019
 *The class BootEmployeeDepartmentDetailsApplication is the SpringBootApplication from which the program begins 
 */
@SpringBootApplication
@ComponentScan("com.cg.BootEmployeeDepartmentDetails")
public class BootEmployeeDepartmentDetailsApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootEmployeeDepartmentDetailsApplication.class, args);
		System.out.println("Welcome to spring boot");
	}

}
