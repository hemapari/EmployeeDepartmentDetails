package com.cg.BootEmployeeDepartmentDetails.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.BootEmployeeDepartmentDetails.dto.Department;
import com.cg.BootEmployeeDepartmentDetails.dto.Employee;
/**@author Hemavathi
 * Wrote on 24-05-2019
 * last modified on 22-05-2019
 * This interface DepartmentDao declares the methods,which extends JpaRepository
 */
public interface DepartmentDao extends JpaRepository<Department, Integer>{
	
	public Department findByName(String name);
}

