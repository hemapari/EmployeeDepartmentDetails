package com.cg.BootEmployeeDepartmentDetails.service;

import java.util.List;

import com.cg.BootEmployeeDepartmentDetails.dto.Department;
import com.cg.BootEmployeeDepartmentDetails.dto.Employee;
import com.cg.BootEmployeeDepartmentDetails.exception.DepartmentNameNotFoundException;

/**@author Hemavathi
 * Wrote on 24-05-20199
 * last modified on 25-05-2019
 * The interface DepartmentService declares the methods
 */
public interface DepartmentService {
	public Department addDepartment(Department department);
	public Department searchByDepartmentName(String name) throws DepartmentNameNotFoundException;

}
