package com.cg.BootEmployeeDepartmentDetails.service;

import java.util.List;

import com.cg.BootEmployeeDepartmentDetails.dto.Employee;
import com.cg.BootEmployeeDepartmentDetails.exception.EmployeeNameNotFoundException;
import com.cg.BootEmployeeDepartmentDetails.exception.IdNotFoundException;

/**@author Hemavathi
 * Wrote on 24-05-2019
 * last modified on 25-05-2019
 * The interface EmployeeService declares the methods
 */
public interface EmployeeService {
	public Employee addEmployee(Employee employee);
	public Employee searchByEmployeeId(int id) throws IdNotFoundException;
	public List<Employee> searchByEmployeeName(String name) throws EmployeeNameNotFoundException;
	public Employee updateEmployee(int id,double salary)throws IdNotFoundException;
}

