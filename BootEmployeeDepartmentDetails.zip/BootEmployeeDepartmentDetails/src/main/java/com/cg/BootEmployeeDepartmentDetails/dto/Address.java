package com.cg.BootEmployeeDepartmentDetails.dto;

import javax.persistence.Entity;

import javax.persistence.Id;
/**@author Hemavathi
 * Wrote on 24-05-2019
 * last modified on 25-05-2019
 * The class Address is the bean which contains description about Address
 */

@Entity
public class Address {
	@Id
	private Integer pincode;
	private String city;
	private String state;
	
	
	public Address() {}

	public Address(String city, String state, Integer pincode) {
		super();
		this.city = city;
		this.state = state;
		this.pincode = pincode;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Integer getPincode() {
		return pincode;
	}

	public void setPincode(Integer pincode) {
		this.pincode = pincode;
	}

	@Override
	public String toString() {
		return "Address [city=" + city + ", state=" + state + ", pincode=" + pincode + "]";
	}
	
	
	
}
