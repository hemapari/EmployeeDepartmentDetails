package com.cg.BootEmployeeDepartmentDetails.dto;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
/**@author Hemavathi
 * Wrote on 24-05-2019
 * last modified on 25-05-2019
 * The class Department is the bean which contains description about Department
 */
@Entity
public class Department {
	@Id
	@Column(name = "d_id")
	private Integer id;
	@Column(name = "d_name")
	private String name;
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "dept_id")
	private List<Employee> employees;

	public Department() {
	}

	public Department(String name, Integer id, List<Employee> employees) {
		super();
		this.name = name;
		this.id = id;
		this.employees = employees;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public List<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}

	@Override
	public String toString() {
		return "Department [name=" + name + ", id=" + id + ", employees=" + employees + "]";
	}

}
/*
 * @OneToMany(cascade=CascadeType.ALL,mappedBy="department")
 * //@JoinColumn(name="dept_id") private List<Employee> employees;
 */